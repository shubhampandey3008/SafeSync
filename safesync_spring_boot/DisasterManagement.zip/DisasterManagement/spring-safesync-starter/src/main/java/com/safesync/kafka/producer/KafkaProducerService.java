package com.safesync.kafka.producer;

import com.safesync.model.Hospital;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KafkaProducerService {

    @Autowired
    private KafkaTemplate<String, Hospital> hospitalKafkaTemplate;

    public void sendToHospital(List<Hospital> hospitalList)
    {
        for(Hospital hospital: hospitalList)
        {
            hospitalKafkaTemplate.send("hospital", hospital);
        }
    }

}
