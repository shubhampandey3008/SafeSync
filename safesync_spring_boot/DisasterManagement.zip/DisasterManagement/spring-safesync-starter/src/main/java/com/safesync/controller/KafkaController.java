package com.safesync.controller;

import com.safesync.kafka.producer.KafkaProducerService;
import com.safesync.model.PayLoad;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.Message;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/safeSync")
public class KafkaController {

    @Autowired
    private KafkaProducerService kafkaProducerService;

    @PostMapping("/kafka/produce")
    public ResponseEntity<?> produce(@RequestBody PayLoad payLoad)
    {
        kafkaProducerService.sendToHospital(payLoad.getHospitalList());
        return new ResponseEntity<>(Map.of("message", "Sucessfully published to the topics"), HttpStatus.OK);
    }
}
