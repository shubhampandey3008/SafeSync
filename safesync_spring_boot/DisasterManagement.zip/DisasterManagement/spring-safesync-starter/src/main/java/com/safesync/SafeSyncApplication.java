package com.safesync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafeSyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafeSyncApplication.class, args);
	}

}
