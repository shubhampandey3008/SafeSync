package com.safesync.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Hospital {
    private String hospitalId;
    private Long beds;
    private Long icu;
    private Long doctors;
    private Long nurses;
    private String message;
    private String location;
}
